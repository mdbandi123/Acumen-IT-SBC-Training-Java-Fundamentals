package org.acumen.training.codes.itema;

/*
Description: This program is the corrected version of erroneous code 7.
			 It displays 4 print statements.
Author: Michael Dave Sumang
Date: September 21, 2024
*/

public class HelloWorld {
	public static void main(String[] args) {
		System.out.println("Hello world");
		System.out.println("Do you like this program?");
		System.out.println();
		System.out.println("I wrote it myself.");
	}
}
