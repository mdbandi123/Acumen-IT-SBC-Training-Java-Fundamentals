package org.acumen.training.codes.itemc;

//**************************************************************
//Adds two variables together and displays their sum and product
//**************************************************************
public class SumProd {
	public static void main(String[] args){
		final int INT2 = 8; 
		final int INT1 = 20; 
		System.out.println("The sum of " + INT1 + " and " + INT2 + " is " + (INT1+INT2)); 
		System.out.println("Their product is " + (INT1*INT2)); 
	}
}
