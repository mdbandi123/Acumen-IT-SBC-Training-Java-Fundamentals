package org.acumen.training.codes.itemg;

/*
Description: Declares f and k and sets values
Author: Michael Dave Sumang
Date: September 21, 2024
*/

public class DeclareMe {
	public static void main(String[] args) {
		float f;
		int k;
		
		k = 22;
		f = k;
		
		System.out.println("Value of k: "+k);
		System.out.println("Value of f: "+f);
	}
}
