package org.acumen.training.codes.itema;

/*
Description: This program is the corrected version of erroneous code 2.
			 It outputs 3 print statements.
Author: Michael Dave Sumang
Date: September 21, 2024
*/

public class Message {
	public static void main(String[] args) {
		System.out.println("Hello, world!");
		printMessage();
	}
	
	/*
	Input parameters: none
	Out parameters: void
	Description: outputs 2 print statements.
	 */
	public static void printMessage() {
		System.out.println("This program surely cannot");
		System.out.println("have any so-called \"errors\" in it");
	}
}
