package org.acumen.training.codes.itema;

/*
Description: This program is the corrected version of erroneous code 4.
			 It outputs 5 print statements.
Author: Michael Dave Sumang
Date: September 21, 2024
*/

public class Problems {
	
	public static void main(String[] args){
		System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
		System.out.println("This program used to have lots of problems,");
		System.out.println("but if it prints this, you fixed them all.");
		System.out.println(" *** Hurray! ***");
		System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
	}
}
